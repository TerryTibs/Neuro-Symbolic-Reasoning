from __future__ import annotations
import json, os, random, time, platform
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from sacrsn_v32 import V32Config, SACRSNv32, total_objective


def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_controlled_data(vocab_size: int = 16, n_sequences: int = 256, length: int = 24):
    """
    Synthetic modular-successor sequences. This validates next-symbol learning
    and transition instrumentation only; it is not a semantic reasoning task.
    """
    data = []
    for _ in range(n_sequences):
        start = random.randrange(vocab_size)
        seq = [(start + i) % vocab_size for i in range(length + 1)]
        data.append(seq)
    return torch.tensor(data, dtype=torch.long)


def main():
    cfg = V32Config()
    seed_everything(cfg.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    run_dir = Path("runs") / f"fresh_{stamp}_seed{cfg.seed}"
    run_dir.mkdir(parents=True, exist_ok=False)

    print(f"SACRSN v32.0 | device={device} | fresh initialization")
    print("No checkpoint loading or training resume is performed.")
    model = SACRSNv32(cfg).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate)
    data = make_controlled_data(cfg.vocab_size).to(device)

    history = []
    for epoch in range(cfg.epochs):
        order = torch.randperm(data.shape[0], device=device)
        totals = {"total": 0.0, "prediction": 0.0, "graph": 0.0,
                  "effective_symbols": 0.0, "ponder": 0.0, "halt_mass": 0.0}
        batches = 0
        for start in range(0, len(order), 32):
            batch = data[order[start:start+32]]
            previous_symbols = None
            optimizer.zero_grad(set_to_none=True)
            losses = []
            graph_losses = []
            prediction_losses = []
            effective = []
            ponders = []
            halt_masses = []
            # Process sequence causally, retaining symbol IDs for graph supervision.
            for t in range(batch.shape[1] - 1):
                x = batch[:, t]
                y = batch[:, t + 1]
                logits, q, graph_loss, ponder, halt_probs, halt_mass, pointer = model(x, previous_symbols)
                pred = F.cross_entropy(logits, y)
                obj = total_objective(pred, q, graph_loss, ponder, cfg)
                losses.append(obj["total"])
                prediction_losses.append(pred.detach())
                graph_losses.append(graph_loss)
                effective.append(q["effective_symbols"])
                ponders.append(ponder.detach())
                halt_masses.append(halt_mass.mean().detach())
                previous_symbols = q["indices"].detach()
            loss = torch.stack(losses).mean()
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            totals["total"] += float(loss.detach())
            totals["prediction"] += float(torch.stack(prediction_losses).mean())
            totals["graph"] += float(torch.stack(graph_losses).mean().detach())
            totals["effective_symbols"] += float(torch.stack(effective).mean())
            totals["ponder"] += float(torch.stack(ponders).mean())
            totals["halt_mass"] += float(torch.stack(halt_masses).mean())
            batches += 1

        record = {k: v / max(batches, 1) for k, v in totals.items()}
        record["epoch"] = epoch
        record["grad_norm"] = float(grad_norm)
        history.append(record)
        if epoch % 25 == 0 or epoch == cfg.epochs - 1:
            print(
                f"Ep {epoch:03d} | Loss {record['total']:.4f} | "
                f"Graph {record['graph']:.4f} | Effective symbols {record['effective_symbols']:.2f} | "
                f"ACT steps {record['ponder']:.2f} | halt mass {record['halt_mass']:.4f} | "
                f"grad {record['grad_norm']:.3f}"
            )

    report = {
        "project": "SACRSN v32.0",
        "status": "mechanism-validation prototype; not evidence of general reasoning",
        "device": str(device),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "seed": cfg.seed,
        "config": cfg.__dict__,
        "history": history,
        "final_codebook_usage": float(history[-1]["effective_symbols"]),
        "final_graph_loss": float(history[-1]["graph"]),
        "final_mean_ponder_steps": float(history[-1]["ponder"]),
        "checkpoint_policy": "fresh initialization; no checkpoint loaded",
    }
    with open(run_dir / "report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    torch.save({"model_state_dict": model.state_dict(), "config": cfg.__dict__},
               run_dir / "sacrsn_v32.pt")
    print(f"\nSaved fresh run to: {run_dir}")
    print("Interpretation warning: inspect unit-test results and held-out tests before drawing conclusions.")


if __name__ == "__main__":
    main()
