from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, Tuple, Dict, Any
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class V32Config:
    vocab_size: int = 16
    embedding_dim: int = 32
    n_symbols: int = 32
    stack_size: int = 16
    max_reasoning_steps: int = 6
    diversity_weight: float = 0.10
    commitment_weight: float = 0.25
    graph_weight: float = 0.20
    ponder_weight: float = 0.01
    graph_bias_scale: float = 0.0  # Disabled in assignment path by design.
    learning_rate: float = 2e-3
    epochs: int = 250
    seed: int = 42


class ComplexLinear(nn.Module):
    """Complex linear map represented by two real linear maps."""
    def __init__(self, dim: int):
        super().__init__()
        self.real = nn.Linear(dim, dim, bias=False)
        self.imag = nn.Linear(dim, dim, bias=False)
        nn.init.orthogonal_(self.real.weight)
        nn.init.orthogonal_(self.imag.weight)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return torch.complex(
            self.real(z.real) - self.imag(z.imag),
            self.real(z.imag) + self.imag(z.real)
        )


class ComplexLayerNorm(nn.Module):
    """Normalises magnitude while preserving phase."""
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.bias = nn.Parameter(torch.zeros(dim))
        self.eps = eps

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        mag = z.abs()
        mean = mag.mean(dim=-1, keepdim=True)
        var = mag.var(dim=-1, keepdim=True, unbiased=False)
        norm = (mag - mean) / torch.sqrt(var + self.eps)
        norm = norm * self.weight + self.bias
        # Avoid negative magnitude after affine transform.
        norm = F.relu(norm)
        phase = torch.angle(z)
        return torch.polar(norm, phase)


class SymbolQuantizer(nn.Module):
    """
    Vector quantisation with explicit assignment logits.
    Diversity is computed from differentiable soft assignments, not a detached
    running-frequency buffer. Hard assignments are used for the forward symbol.
    """
    def __init__(self, dim: int, n_symbols: int, temperature: float = 0.7):
        super().__init__()
        self.dim = dim
        self.n_symbols = n_symbols
        self.temperature = temperature
        self.codebook = nn.Parameter(torch.randn(n_symbols, dim * 2) * 0.15)

    def forward(self, z: torch.Tensor) -> Dict[str, torch.Tensor]:
        flat = torch.cat([z.real, z.imag], dim=-1)
        distances = (
            flat.pow(2).sum(-1, keepdim=True)
            + self.codebook.pow(2).sum(-1).unsqueeze(0)
            - 2.0 * flat @ self.codebook.t()
        ).clamp_min(0.0)
        logits = -distances / self.temperature
        soft = F.softmax(logits, dim=-1)
        indices = logits.argmax(dim=-1)
        hard = F.embedding(indices, self.codebook)
        # Straight-through hard quantisation.
        quantized = flat + (hard - flat).detach()
        vq_loss = F.mse_loss(hard, flat.detach())
        commitment = F.mse_loss(flat, hard.detach())

        # Batch marginal distribution. This has a gradient through soft assignments.
        marginal = soft.mean(dim=0)
        entropy = -(marginal * torch.log(marginal.clamp_min(1e-9))).sum()
        diversity_loss = -entropy

        qz = torch.complex(quantized[..., :self.dim], quantized[..., self.dim:])
        return {
            "z_q": qz,
            "indices": indices,
            "soft_assignments": soft,
            "vq_loss": vq_loss,
            "commitment_loss": commitment,
            "diversity_loss": diversity_loss,
            "usage_entropy": entropy.detach(),
            "effective_symbols": entropy.detach().exp(),
        }


class TransitionGraph(nn.Module):
    """
    Directed transition model. It is trained from observed symbol pairs.
    Graph scores do not alter quantizer assignments in v32.0, avoiding the
    self-reinforcing assignment/graph feedback loop present in v31.
    """
    def __init__(self, n_symbols: int):
        super().__init__()
        self.logits = nn.Parameter(torch.zeros(n_symbols, n_symbols))

    def loss(self, previous: torch.Tensor, current: torch.Tensor) -> torch.Tensor:
        return F.cross_entropy(self.logits[previous.reshape(-1)], current.reshape(-1))

    @torch.no_grad()
    def probabilities(self) -> torch.Tensor:
        return F.softmax(self.logits, dim=-1)


class DifferentiableStack(nn.Module):
    """
    Bounded non-circular stack with soft pointer movement.
    Index 0 is the bottom; higher indices are deeper/topward locations.
    Push shifts pointer mass upward; pop shifts it downward. Boundary mass is
    clamped rather than wrapped with torch.roll.
    """
    def __init__(self, dim: int, capacity: int):
        super().__init__()
        self.dim = dim
        self.capacity = capacity

    def _shift_up(self, ptr: torch.Tensor) -> torch.Tensor:
        out = torch.zeros_like(ptr)
        out[:, 1:] = ptr[:, :-1]
        out[:, -1] += ptr[:, -1]
        return out

    def _shift_down(self, ptr: torch.Tensor) -> torch.Tensor:
        out = torch.zeros_like(ptr)
        out[:, :-1] = ptr[:, 1:]
        out[:, 0] += ptr[:, 0]
        return out

    def forward(
        self, value: torch.Tensor, memory: torch.Tensor,
        pointer: torch.Tensor, controls: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # controls are push, pop, no-op probabilities
        controls = F.softmax(controls, dim=-1)
        push, pop, noop = controls[:, 0:1], controls[:, 1:2], controls[:, 2:3]
        pushed = self._shift_up(pointer)
        popped = self._shift_down(pointer)
        new_pointer = push * pushed + pop * popped + noop * pointer
        new_pointer = new_pointer / new_pointer.sum(dim=-1, keepdim=True).clamp_min(1e-9)

        value_flat = torch.cat([value.real, value.imag], dim=-1)
        # Write to the destination selected by the pushed pointer, weighted by push.
        write_weights = push * pushed
        write = write_weights.unsqueeze(-1) * value_flat.unsqueeze(1)
        retained = memory * (1.0 - write_weights.unsqueeze(-1))
        new_memory = retained + write

        read_flat = (new_memory * new_pointer.unsqueeze(-1)).sum(dim=1)
        read = torch.complex(read_flat[:, :self.dim], read_flat[:, self.dim:])
        return read, new_memory, new_pointer


class ReasoningCell(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.linear = ComplexLinear(dim)
        self.norm = ComplexLayerNorm(dim)
        self.halt = nn.Linear(dim * 2, 1)
        self.stack_control = nn.Linear(dim * 2, 3)

    def forward(self, z: torch.Tensor):
        z = self.norm(self.linear(z))
        flat = torch.cat([z.real, z.imag], dim=-1)
        halt_probability = torch.sigmoid(self.halt(flat))
        stack_logits = self.stack_control(flat)
        return z, halt_probability, stack_logits


def act_unroll(cell, initial_z, max_steps: int, halt_threshold: float = 0.99):
    """
    ACT-style probability allocation.
    The residual probability is assigned to the final step. Ponder cost is
    expected computation depth and remains differentiable through halt logits.
    """
    batch = initial_z.shape[0]
    z = initial_z
    remainder = torch.ones(batch, 1, device=z.device, dtype=z.real.dtype)
    outputs = torch.zeros_like(z)
    halting_mass = torch.zeros_like(remainder)
    expected_steps = torch.zeros_like(remainder)
    halt_probs = []

    for step in range(max_steps):
        z, p_halt, stack_logits = cell(z)
        halt_probs.append(p_halt)
        if step == max_steps - 1:
            weight = remainder
        else:
            active = (halting_mass < halt_threshold).to(remainder.dtype)
            weight = torch.minimum(p_halt * active, remainder)
        outputs = outputs + weight * z
        halting_mass = halting_mass + weight
        remainder = (remainder - weight).clamp_min(0.0)
        expected_steps = expected_steps + weight * float(step + 1)

    # Normalise only for numerical safety; normally the final residual makes sum=1.
    outputs = outputs / halting_mass.clamp_min(1e-9)
    ponder_cost = expected_steps.mean()
    return outputs, ponder_cost, torch.cat(halt_probs, dim=1), halting_mass


class SACRSNv32(nn.Module):
    """
    Mechanism-validation model. Input is a batch of one-step token IDs.
    It returns next-token logits and diagnostics; it is not yet the full
    compositional reasoning system.
    """
    def __init__(self, config: V32Config):
        super().__init__()
        self.config = config
        self.embedding_mag = nn.Embedding(config.vocab_size, config.embedding_dim)
        self.embedding_phase = nn.Embedding(config.vocab_size, config.embedding_dim)
        self.cell = ReasoningCell(config.embedding_dim)
        self.quantizer = SymbolQuantizer(config.embedding_dim, config.n_symbols)
        self.graph = TransitionGraph(config.n_symbols)
        self.stack = DifferentiableStack(config.embedding_dim, config.stack_size)
        self.decoder = nn.Linear(config.embedding_dim * 2, config.vocab_size)

    def embed(self, token_ids: torch.Tensor) -> torch.Tensor:
        mag = F.softplus(self.embedding_mag(token_ids))
        phase = self.embedding_phase(token_ids)
        return torch.polar(mag, phase)

    def forward(self, token_ids: torch.Tensor, previous_symbol: Optional[torch.Tensor] = None):
        z0 = self.embed(token_ids.reshape(-1))
        z, ponder, halt_probs, halt_mass = act_unroll(
            self.cell, z0, self.config.max_reasoning_steps
        )

        batch = z.shape[0]
        memory = torch.zeros(batch, self.config.stack_size, self.config.embedding_dim * 2, device=z.device)
        pointer = torch.zeros(batch, self.config.stack_size, device=z.device)
        pointer[:, 0] = 1.0
        stack_logits = self.cell.stack_control(
            torch.cat([z.real, z.imag], dim=-1)
        )
        stack_read, memory, pointer = self.stack(z, memory, pointer, stack_logits)
        z = z + stack_read

        q = self.quantizer(z)
        logits = self.decoder(torch.cat([q["z_q"].real, q["z_q"].imag], dim=-1))
        if previous_symbol is None:
            graph_loss = torch.zeros((), device=z.device)
        else:
            graph_loss = self.graph.loss(previous_symbol, q["indices"])

        return logits, q, graph_loss, ponder, halt_probs, halt_mass, pointer


def total_objective(
    prediction_loss: torch.Tensor,
    q: Dict[str, torch.Tensor],
    graph_loss: torch.Tensor,
    ponder: torch.Tensor,
    config: V32Config
) -> Dict[str, torch.Tensor]:
    loss = (
        prediction_loss
        + q["vq_loss"]
        + config.commitment_weight * q["commitment_loss"]
        + config.diversity_weight * q["diversity_loss"]
        + config.graph_weight * graph_loss
        + config.ponder_weight * ponder
    )
    return {
        "total": loss,
        "prediction": prediction_loss,
        "vq": q["vq_loss"],
        "commitment": q["commitment_loss"],
        "diversity": q["diversity_loss"],
        "graph": graph_loss,
        "ponder": ponder,
    }
