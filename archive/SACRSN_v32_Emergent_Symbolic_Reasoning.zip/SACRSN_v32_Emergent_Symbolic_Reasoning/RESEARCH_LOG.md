# SACRSN v32 Research Log

## Baseline: v31 (provided terminal output)

Observed:
- Training terminated at epoch 1650 of configured 3000 due to `avg_loss < 0.01`.
- Composite loss reached -0.1724. This is not a valid perfect-convergence criterion because entropy/diversity terms can be negative.
- Reported effective symbol usage fell from 17.5 to roughly 1.4–2.3 out of 64.
- Generated text reproduced fragments of the tiny training corpus.
- Extracted transitions were dominated by self-loops.
- Dream mode emitted only `T`.
- Anomaly plot used transition cross-entropy without calibration or held-out evaluation.

Source-grounded implementation findings:
- v31's diversity statistic is updated under `torch.no_grad()`, so its diversity loss does not train assignments.
- v31's stack uses circular `torch.roll` pointer shifts.
- v31's ponder statistic uses a threshold comparison and is not itself a differentiable halting objective.
- v31's graph adjacency is used both to bias quantizer selection and to predict transitions, creating a coupled feedback path.
- The graph extraction reports state transitions, not formal logical rules.

## v32.0 changes

- Diversity objective uses differentiable soft-assignment marginal entropy.
- Graph transition objective is explicit and graph scores do not bias quantizer assignments.
- Stack pointer shifts are bounded and non-circular.
- ACT-style unrolling assigns residual mass at the final step and computes expected depth.
- Fresh-run policy: no checkpoint loading or resume.

## Open issues / limitations

- This release is a mechanism-validation prototype, not a completed neuro-symbolic reasoning system.
- The current synthetic sequence task is modular successor prediction. It is deliberately simple and does not validate semantic reasoning.
- Stack control is learned but not yet trained against an explicit push/pop task. Dedicated stack behavioural tasks are required in the next stage.
- Symbol interpretability and stability across seeds are not yet tested.
- Codebook collapse must be evaluated across multiple seeds and task distributions.
- A proper ACT benchmark must compare adaptive computation against fixed-depth baselines at matched parameter and compute budgets.
- Formal logic tasks and compositional generalisation are not included in v32.0.
