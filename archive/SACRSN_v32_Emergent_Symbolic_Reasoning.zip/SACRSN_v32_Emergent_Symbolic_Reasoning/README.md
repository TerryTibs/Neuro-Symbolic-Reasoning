# SACRSN v32 — Emergent Symbolic Reasoning Research

**Status:** research foundation / mechanism-validation release. This is not yet evidence of general reasoning or novelty.

## What this release does

1. Preserves the uploaded v31 source as `baseline_v31_original.txt` when available.
2. Implements isolated, testable versions of the mechanisms that were defective or inadequately validated in v31:
   - differentiable symbol-usage diversity objective;
   - graph transition learning separated from symbol assignment;
   - bounded, non-circular differentiable stack;
   - ACT-style halting with differentiable ponder cost;
   - explicit diagnostics and mechanism-level unit tests.
3. Runs controlled synthetic sequence experiments instead of treating a tiny prose memorisation task as a reasoning benchmark.
4. Writes run outputs to a new timestamped directory; it never loads a checkpoint.

## Important scientific boundaries

- The codebook is a learned discrete latent vocabulary. Its existence does not prove that its entries have human-interpretable meanings.
- The graph is a learned transition model. Its edges are not automatically logical rules.
- The stack is differentiable structured memory. It is not automatically a correct symbolic stack until the behavioural tests pass.
- ACT-style halting is a learned computation allocation mechanism. Low step counts alone do not establish efficient reasoning.
- The synthetic tasks in this first release validate mechanisms, not broad intelligence, semantic understanding, or novelty.

## Requirements

Python 3.10+ recommended.

```bash
python -m pip install -r requirements.txt
```

PyTorch installation may need a platform-specific command. For an NVIDIA GPU, install the CUDA-enabled PyTorch build appropriate to your driver from https://pytorch.org/get-started/locally/.

## Run

From this folder:

```bash
python run_v32.py
```

The script:
1. prints the selected device;
2. runs unit tests;
3. trains a small controlled next-symbol experiment from fresh initialization;
4. reports prediction loss, codebook usage, transition accuracy, mean ACT steps and gradient diagnostics;
5. saves a JSON report and model checkpoint inside `runs/<timestamp>/`.

Run only the unit tests:

```bash
python -m unittest discover -s tests -v
```

No prior checkpoint is loaded. Every invocation creates a separate run directory.

## First release acceptance criteria

The unit tests must establish:
- diversity loss has a non-zero gradient to assignment logits;
- graph transition loss updates graph parameters independently of quantizer assignment;
- stack pointers do not wrap from the top to the bottom;
- stack push/pop operations move pointer mass in the expected direction;
- ACT ponder cost has a gradient path to halt logits;
- ACT output weights sum to approximately one when the final step absorbs remaining probability.

Training metrics are descriptive. A successful run is not proof of reasoning.

## Research sequence

- **v32.0:** mechanism repair and validation foundation.
- **v32.1:** explicit compositional toy tasks: equality, successor, copy/reversal and nested push/pop.
- **v32.2:** symbol stability, permutation tests, held-out compositions and causal ablations.
- **v32.3:** compare against non-symbolic and non-recursive baselines.
- **v33:** only after evidence warrants a larger architecture.

## Reproducibility

The seed, configuration, environment, training metrics and diagnostic values are saved per run. GPU kernels can still be nondeterministic depending on hardware and operations. The report records the selected device and seed.

## What this release deliberately does not claim

It does not claim that SACRSN has achieved autonomous symbol emergence, formal theorem proving, ethical reasoning, anomaly detection, or human-like reasoning. Those require separate operational definitions and experiments.
