import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import unittest
import torch
import torch.nn as nn
from sacrsn_v32 import (
    SymbolQuantizer, TransitionGraph, DifferentiableStack,
    act_unroll
)


class TinyCell(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.halt_logit = nn.Parameter(torch.tensor(-1.0))
    def forward(self, z):
        p = torch.sigmoid(self.halt_logit).expand(z.shape[0], 1)
        return z * 0.9, p, torch.zeros(z.shape[0], 3, device=z.device)


class TestMechanisms(unittest.TestCase):
    def test_diversity_loss_has_gradient(self):
        torch.manual_seed(1)
        q = SymbolQuantizer(dim=4, n_symbols=8)
        z = torch.complex(torch.randn(32, 4), torch.randn(32, 4))
        out = q(z)
        out["diversity_loss"].backward()
        self.assertIsNotNone(q.codebook.grad)
        self.assertGreater(float(q.codebook.grad.abs().sum()), 0.0)

    def test_graph_loss_updates_graph_parameters(self):
        graph = TransitionGraph(5)
        before = graph.logits.detach().clone()
        prev = torch.tensor([0, 1, 2, 3])
        curr = torch.tensor([1, 2, 3, 4])
        loss = graph.loss(prev, curr)
        loss.backward()
        self.assertIsNotNone(graph.logits.grad)
        self.assertGreater(float(graph.logits.grad.abs().sum()), 0.0)
        self.assertTrue(torch.equal(before, graph.logits.detach()))

    def test_stack_does_not_wrap(self):
        stack = DifferentiableStack(dim=2, capacity=4)
        ptr = torch.tensor([[0., 0., 0., 1.]])
        shifted = stack._shift_up(ptr)
        self.assertTrue(torch.equal(shifted, ptr))
        down = stack._shift_down(ptr)
        self.assertTrue(torch.equal(down, torch.tensor([[0., 0., 1., 0.]])))

    def test_stack_push_pop_direction(self):
        stack = DifferentiableStack(dim=2, capacity=5)
        ptr = torch.tensor([[1., 0., 0., 0., 0.]])
        self.assertEqual(int(stack._shift_up(ptr).argmax()), 1)
        self.assertEqual(int(stack._shift_down(torch.tensor([[0., 0., 1., 0., 0.]])).argmax()), 1)

    def test_act_ponder_has_gradient(self):
        cell = TinyCell(3)
        z = torch.complex(torch.ones(4, 3), torch.ones(4, 3))
        _, ponder, _, mass = act_unroll(cell, z, max_steps=5, halt_threshold=0.99)
        ponder.backward()
        self.assertIsNotNone(cell.halt_logit.grad)
        self.assertGreater(abs(float(cell.halt_logit.grad)), 0.0)
        self.assertTrue(torch.allclose(mass, torch.ones_like(mass), atol=1e-5))

    def test_quantizer_outputs_valid_symbol_ids(self):
        q = SymbolQuantizer(dim=4, n_symbols=7)
        z = torch.complex(torch.randn(10, 4), torch.randn(10, 4))
        out = q(z)
        self.assertEqual(tuple(out["indices"].shape), (10,))
        self.assertTrue(bool((out["indices"] >= 0).all()))
        self.assertTrue(bool((out["indices"] < 7).all()))


if __name__ == "__main__":
    unittest.main()
