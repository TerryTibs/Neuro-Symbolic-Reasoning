"""Focused regression tests for SACRSN v60.1.

Run from a terminal:
    python test_sacrsn_v60_1.py
"""
import importlib.util
import os
import sys
import tempfile
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sacrsn_v60_1.py"
spec = importlib.util.spec_from_file_location("sacrsn_v60_1_under_test", SOURCE)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print("[PASS]", message)


def test_tokenizer_roundtrip():
    training_text = "hello world\nknown punctuation ! ?"
    tok = mod.DualClockPolarTokenizer(training_text)
    cases = [
        "hello Ω world",
        "hello 🙂 world",
        "hello\tworld",
        "café déjà vu",
        "plain ASCII",
        "don't stop",
        "combining: e\u0301",
        "emoji sequence 👩‍🚀",
        "unseen punctuation § — …",
    ]
    for original in cases:
        enc = tok.encode_atomic(original)
        decoded = tok.decode_atomic(enc["stems"], enc["morphs"], enc["edges"])
        check(decoded == original, f"atomic round-trip: {original!r}")
        check(int(enc["chars"].sum().item()) == len(original),
              f"character count exact: {original!r}")

        packed = mod.pack_atomic_to_packets(enc, macro_trie=None, max_pkt_len=4)
        packet_list = []
        for row in range(packed["stems"].shape[0]):
            length = int(packed["lens"][row].item())
            packet_list.append(list(zip(
                packed["stems"][row, :length].tolist(),
                packed["morphs"][row, :length].tolist(),
                packed["edges"][row, :length].tolist(),
            )))
        decoded_packed = tok.decode_packets(packet_list)
        check(decoded_packed == original, f"packed round-trip: {original!r}")
    return tok


def test_model_forward_and_act(tok):
    model = mod.UberCRSN(
        tok.vocab_size,
        mod.CONFIG["embedding_dim"],
        n_morph_classes=tok.n_morphs,
        n_edge_classes=tok.n_edges,
    ).to(mod.DEVICE)

    enc = tok.encode_atomic("hello world")
    stems = enc["stems"][:2].view(1, 2).to(mod.DEVICE)
    morphs = enc["morphs"][:2].view(1, 2).to(mod.DEVICE)
    edges = enc["edges"][:2].view(1, 2).to(mod.DEVICE)
    lens = torch.tensor([2], dtype=torch.long, device=mod.DEVICE)

    # Force a high halting probability: ACT must halt after the first iteration.
    with torch.no_grad():
        model.cell.halt_linear.weight.zero_()
        model.cell.halt_linear.bias.fill_(5.0)

    output = model(
        stems, morphs, lens,
        prev_edge=edges[:, -1],
        pkt_edges=edges,
        hidden=None,
        prev_sym=None,
        tgt_stems=stems,
        tgt_morphs=morphs,
        tgt_edges=edges,
        decode_slots=2,
        return_stats=True,
    )
    check(output[0].shape[:2] == (1, 2), "model decoder returns two slot logits")
    check(output[17]["edge_logits"].shape[:2] == (1, 2), "edge decoder returns two slot logits")
    check(float(output[11][0].item()) == 1.0, "ACT threshold crossing halts after one step")
    check(output[7].shape[0] == 1, "ACT loop exits after all batch members halt")

    # Confirm the edge input participates in a differentiable path.
    with torch.no_grad():
        model.cell.halt_linear.bias.fill_(-2.0)
    model.zero_grad(set_to_none=True)
    output = model(
        stems, morphs, lens,
        prev_edge=edges[:, -1],
        pkt_edges=edges,
        tgt_stems=stems,
        tgt_morphs=morphs,
        tgt_edges=edges,
        decode_slots=2,
        return_stats=True,
    )
    loss = output[0].float().square().mean() + output[17]["edge_logits"].float().square().mean()
    loss.backward()
    grad = model.edge_emb.weight.grad
    check(grad is not None and torch.isfinite(grad).all() and grad.norm().item() > 0,
          "packet-edge stream receives finite non-zero gradients")
    check(abs(float(output[8].sum().item()) - 1.0) < 1e-5,
          "ACT probability mass sums to one")
    return model


def test_checkpoint(model, tok):
    mod.tokenizer = tok
    mod.vocab_size = tok.vocab_size
    mod.n_morphs = tok.n_morphs
    mod.n_edges = tok.n_edges
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "model.pth"
        mod.save_checkpoint(model, str(path), macro_trie=None)
        loaded, payload = mod.load_checkpoint(str(path), map_location=mod.DEVICE)
        check(payload["format_version"] == "SACRSN-v60.1", "checkpoint format version recorded")
        check(len(mod.tokenizer.edge_vocab) == tok.n_edges, "checkpoint restores tokenizer edge vocabulary")
        sample = "hello 🙂 Ω"
        enc = mod.tokenizer.encode_atomic(sample)
        decoded = mod.tokenizer.decode_atomic(enc["stems"], enc["morphs"], enc["edges"])
        check(decoded == sample, "loaded checkpoint tokenizer preserves unseen Unicode")
        for key, value in model.state_dict().items():
            check(torch.equal(value.detach().cpu(), loaded.state_dict()[key].detach().cpu()),
                  f"checkpoint restores parameter {key}")


if __name__ == "__main__":
    tokenizer = test_tokenizer_roundtrip()
    model = test_model_forward_and_act(tokenizer)
    test_checkpoint(model, tokenizer)
    print("\nALL SACRSN v60.1 REGRESSION TESTS PASSED")
