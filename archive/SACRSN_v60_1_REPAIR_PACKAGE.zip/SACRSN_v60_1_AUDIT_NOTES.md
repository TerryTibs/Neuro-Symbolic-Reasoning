# SACRSN v60.1 — repair package

## What changed from the supplied v60 source

### 1. ACT halting semantics
- At the first step where cumulative halting probability reaches `act_threshold`, that sample receives all remaining probability mass.
- Its residual mass becomes zero, its stack state stops updating, and it is excluded from later step counts.
- The recursive loop exits once every sample in the batch has halted.
- This corrects the previous mismatch between the reported ACT step count and the probability-weighted computation used to form the output.

Note: in a mixed batch, already-halted rows still pass through some tensor operations while other rows remain active. Their ACT weight is zero and their stack state is frozen, but this is not fully compacted per-sample execution. The batch loop exits as soon as all rows have halted.

### 2. Packet structural-edge stream
- The model now accepts the complete input packet edge sequence (`pkt_edges`).
- Packet edges are combined using positional complex rotations and routed to the Relational Operator and Stack channels, rather than being discarded except for the final edge.
- The causal slot decoder now conditions on the previous slot's stem, morphology, and edge.
- Training, validation, and macro-discovery paths pass the edge sequences explicitly.

This is a learned positional superposition, not a mathematically lossless edge code. Reconstruction accuracy still needs evaluation across packet lengths and boundary patterns.

### 3. Reversible UTF-8 tokenizer fallback
- Reserves 256 byte edge IDs.
- Unseen separator characters are encoded as their UTF-8 bytes and reconstructed as a byte stream.
- Ensures the basic ASCII alphabet, digits, and apostrophe are available for character fallback even when absent from the training corpus.
- Character counts assign one character to each UTF-8 lead byte (or ASCII byte) and zero to continuation bytes.
- Checkpoint metadata stores the byte-token range.

### 4. Macro discovery
- The fallback selection path now relaxes frequency only.
- It no longer promotes phrases that failed the configured ACT, NoOp, or relational-consistency thresholds.
- Macro discovery remains a one-time Phase-3 scan, not a continuously evolving vocabulary.

### 5. Evaluation and experiment outputs
- Validation now restores the model's previous train/eval mode instead of always forcing training mode.
- The relational metric is labelled `RelCons` (relational consistency), not `RelAcc`.
- PDDL output is labelled as token next-step accuracy; it is not represented as proof of planning or action legality.
- Training exports `model_training_history.csv` and `model_training_history.json`.
- Each normal script launch creates a unique `runs/SACRSN_v60_1_YYYYMMDD_HHMMSS/` directory.
- `data.txt` is resolved from the current working directory first, then from the script directory.
- Checkpoints carry a format version and tokenizer byte metadata. `load_checkpoint()` restores model weights and a usable tokenizer for inference/decoding.

`load_checkpoint()` is an inference loader, not a faithful training-resume function. Optimizer, scheduler, epoch position, and RNG states are not saved.

## Verification performed

- Python compilation: passed.
- 120 focused regression assertions: passed.
- 1,000 randomized Unicode/ASCII round-trip strings: passed.
- Atomic and packetized round-trip tests: passed, including emoji, combining marks, tabs, unseen punctuation, and non-ASCII text.
- CPU forward pass and backward pass: passed.
- Forced high-halting-probability test: ACT halted after one step and exited the loop.
- Packet-edge gradient test: finite, non-zero gradient reached the edge embedding.
- Checkpoint save/load test: passed, including restoration of tokenizer byte metadata and model parameters.
- One-epoch CPU training-loop smoke test on a small synthetic corpus: passed; CSV and JSON history files were created.

The smoke test is an execution test only. It is not evidence of useful convergence or language/reasoning quality.

## Remaining work before treating SACRSN as scientifically validated

1. Build an independent temporal relational prediction test. Current `RelCons` remains a consistency diagnostic because the relation is derived from the current observation; it is not an independent next-state prediction benchmark.
2. Replace the PDDL token-sequence probe with action-precondition, legal-transition, goal-satisfaction, multi-step planning, and held-out configuration tests.
3. Measure macro reconstruction and generalisation by packet length, internal edge pattern, and unseen phrase combinations.
4. Test stack overflow/underflow, memory interference, codebook stability, and multi-seed variance.
5. Add exact training-resume checkpoints if training continuation is required.
6. Run a full training experiment on the target GPU and inspect the complete logs, memory use, validation curves, and saved diagnostics.

No full-length training run or target-GPU performance benchmark has been performed as part of this repair.
