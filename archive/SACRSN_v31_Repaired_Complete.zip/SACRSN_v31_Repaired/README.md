# SACRSN v31.1 — Repaired Observable Edition

This package is a repaired implementation based on the supplied 626-line
`SACRSN v31: THE OBSERVABLE EDITION` source. The original is retained in
`baseline_v31_original.txt` for comparison.

## Run on Windows / VS Code

1. Open this folder in VS Code.
2. In the terminal, create/activate your Python environment.
3. Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

4. Start a fresh run:

```powershell
python sacrsn_v31.py
```

Optional shorter smoke run:

```powershell
python sacrsn_v31.py --epochs 5 --device auto
```

Use a larger corpus:

```powershell
python sacrsn_v31.py --text-file path\to\your_corpus.txt --epochs 1000
```

Each run writes to a new `runs/fresh_<timestamp>_seed<seed>` directory.
No checkpoint is loaded. The script saves a checkpoint, JSON training report,
symbol transition counts, transition matrix CSV, generated sample, and (if
matplotlib is installed) a transition heatmap.

## What was repaired

- ACT uses differentiable probability mass and a differentiable expected-step
  penalty. It no longer uses a thresholded boolean mask that severs gradients.
- Final ACT step receives the remaining probability mass, so weights sum to one.
- Stack pointer movement is bounded and non-circular; it cannot wrap from one
  end of memory to the other.
- Stack memory and recurrent state persist across tokens in a sequence.
- Stack control is applied at every recursive step.
- Recursive attention attends over the current token's accumulated recursive
  states rather than attending to a sequence of length one.
- VQ usage diversity is computed from differentiable soft assignments over a
  batch/sequence, not a no-gradient EMA buffer.
- Graph transition learning is separated from symbol assignment. The graph
  does not bias quantizer selection, avoiding a self-reinforcing assignment loop.
- Training uses a sequence batch and backpropagates through the unrolled token
  sequence; no accidental per-character graph detachment.
- Prediction loss and validation NLL are reported separately from auxiliary
  losses. There is no “perfect convergence” shortcut based on composite loss.
- Usage perplexity is calculated from the actual aggregate symbol distribution.
- Anomaly threshold is calibrated from held-out validation surprisal and is
  explicitly described as a language-model proxy, not ethics.
- Transition extraction is labelled as empirical latent-symbol transitions,
  not “logic rules”.
- Every run starts from fresh random initialisation.

## Scientific limitations

The default corpus is tiny and highly repetitive. A low validation loss on it
would show only next-character prediction on this corpus. The graph records
latent-symbol transition regularities; it does not encode formal propositions,
proof rules, causal relations, or normative ethical principles. The model has
not been shown to perform compositional reasoning, theorem proving, or robust
semantic anomaly detection.

The code is a repaired research baseline, not a claim that every research
hypothesis in the original project has been validated.
