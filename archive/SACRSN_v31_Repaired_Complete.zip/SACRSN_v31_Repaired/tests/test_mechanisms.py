import unittest
import torch

from sacrsn_v31 import (
    Config, DifferentiableStack, SACRSNv31, SymbolQuantizer,
    sequence_objective, set_seed
)


class TestRepairedV31(unittest.TestCase):
    def setUp(self):
        set_seed(7)
        self.cfg = Config(
            embedding_dim=8, n_symbols=8, max_recursion_depth=3,
            stack_size=4, batch_size=2, sequence_length=5,
            epochs=2, log_every=1
        )

    def test_stack_pointer_does_not_wrap(self):
        stack = DifferentiableStack(2, 4)
        z = torch.complex(torch.ones(1, 2), torch.zeros(1, 2))
        memory = torch.zeros(1, 4, 4)
        ptr = torch.tensor([[0., 0., 0., 1.]])
        # push at highest index must clamp, not wrap to index zero
        control = torch.tensor([[1., 0., 0.]])
        _, _, new_ptr = stack(z, memory, ptr, control)
        self.assertEqual(int(new_ptr.argmax()), 3)

    def test_stack_push_moves_one_slot(self):
        stack = DifferentiableStack(2, 4)
        z = torch.complex(torch.ones(1, 2), torch.zeros(1, 2))
        memory = torch.zeros(1, 4, 4)
        ptr = torch.tensor([[1., 0., 0., 0.]])
        control = torch.tensor([[1., 0., 0.]])
        _, _, new_ptr = stack(z, memory, ptr, control)
        self.assertEqual(int(new_ptr.argmax()), 1)

    def test_quantizer_diversity_has_gradient(self):
        q = SymbolQuantizer(4, 8)
        z = torch.complex(torch.randn(12, 4), torch.randn(12, 4)).requires_grad_()
        _, _, soft, _, _ = q(z)
        usage = soft.mean(0)
        diversity = (usage * usage.clamp_min(1e-8).log()).sum()
        diversity.backward()
        self.assertIsNotNone(z.grad)
        self.assertGreater(float(z.grad.abs().sum()), 0.0)

    def test_act_ponder_has_gradient(self):
        model = SACRSNv31(10, self.cfg)
        x = torch.randint(0, 10, (2,))
        _, _, metrics = model.forward_step(x)
        metrics["ponder"].backward()
        grad = model.cell.halt.weight.grad
        self.assertIsNotNone(grad)
        self.assertGreater(float(grad.abs().sum()), 0.0)

    def test_graph_loss_updates_graph(self):
        model = SACRSNv31(10, self.cfg)
        previous = torch.tensor([1, 2])
        current = torch.tensor([3, 4])
        loss = model.graph.loss(previous, current)
        loss.backward()
        self.assertIsNotNone(model.graph.logits.grad)
        self.assertGreater(float(model.graph.logits.grad.abs().sum()), 0.0)

    def test_sequence_training_backward_finite(self):
        model = SACRSNv31(10, self.cfg)
        x = torch.randint(0, 10, (2, 5))
        y = torch.randint(0, 10, (2, 5))
        loss, metrics = sequence_objective(model, x, y, self.cfg)
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertGreater(float(metrics["usage_perplexity"]), 1.0)

    def test_state_persists_across_tokens(self):
        model = SACRSNv31(10, self.cfg)
        _, state1, _ = model.forward_step(torch.tensor([1]))
        _, state2, _ = model.forward_step(torch.tensor([2]), state1)
        self.assertEqual(tuple(state2.stack_memory.shape), (1, 4, 16))
        self.assertEqual(tuple(state2.recurrent.shape), (1, 8))


if __name__ == "__main__":
    unittest.main()
