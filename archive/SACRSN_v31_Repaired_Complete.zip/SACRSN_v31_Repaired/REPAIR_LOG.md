# SACRSN v31.1 Repair Log

## Baseline
Supplied source: `SACRSN v31: THE OBSERVABLE EDITION`, 626 lines.
The exact original source is preserved as `baseline_v31_original.txt`.

## Critical defects addressed
1. Thresholded ACT running mask did not provide a useful gradient to halt
   probabilities. Replaced with differentiable remaining-mass ACT weighting.
2. ACT final step now consumes all remaining mass.
3. `torch.roll` stack pointer wrapped across boundaries. Replaced by bounded
   shifts with no circular wrap.
4. Stack state is passed between tokens and updated within every recursive step.
5. Original attention operated on a one-token tensor, making it effectively
   trivial. Replaced with attention over accumulated recursive states.
6. Diversity penalty was calculated from a buffer updated under `no_grad`;
   it could not train assignments. Replaced with differentiable soft assignment
   aggregate entropy across the batch and time dimension.
7. Graph bias was fed into quantizer distances, allowing topology to reinforce
   its own symbol assignments. Graph training is now a separate transition loss.
8. The original per-character optimizer step and detach pattern did not train
   temporal state end-to-end. Replaced with sequence-level BPTT over sampled
   chunks.
9. Composite loss could become negative and triggered false “perfect
   convergence”. Removed that stopping rule; validation NLL is reported
   independently and best validation state is retained.
10. Original "Usage(PPX)" was effective symbol count, not language-model
    perplexity. It is now explicitly named `usage_perplexity`.
11. Original “ethical” score was next-symbol transition CE, not ethics. Reframed
    as graph transition learning.
12. Original “logic rules” were transition counts. Reframed as empirical latent
    transitions.
13. Original anomaly plot had no held-out calibration. Added validation
    surprisal calibration and narrowed the claim to language-model anomaly proxy.

## Tests
The `tests` directory contains unit tests for stack boundaries, stack movement,
diversity gradients, ACT gradients, graph gradients, finite sequence training,
and persistent state shapes. Run:

```powershell
python -m unittest discover -s tests -v
```

## Not yet demonstrated
- Formal logic extraction or theorem proving
- Normative ethical reasoning
- Compositional generalisation
- Robust anomaly detection beyond the supplied validation distribution
- Novelty relative to existing neural, recurrent, ACT, VQ, or neural-stack work
